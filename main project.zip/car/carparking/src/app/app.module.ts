import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import {router} from './app.router';
import {HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AngularFireModule} from '@angular/fire'; 
// import {AuthProviders, AuthMethods, AngularFireAuth } from '@angular/fire';
import { FormsModule, ReactiveFormsModule,FormBuilder } from '@angular/forms';
import {config, firebaseAuthConfig} from './app.config';
import {UserService} from './components/Services/userService';
import {AuthGuard} from './components/Services/authGuard';
// import {StoreModule} from '@store';
import { NgReduxModule } from 'ng2-redux';
import { AngularFireDatabaseModule, AngularFireDatabase } from 'angularfire2/database';
import { AngularFireAuthModule, AngularFireAuth } from 'angularfire2/auth';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BookinglistComponent } from './components/bookinglist/bookinglist.component';
import { BookingformComponent } from './components/bookingform/bookingform.component';
import { FeedbackformComponent } from './components/feedbackform/feedbackform.component';
import { MessagesComponent } from './components/messages/messages.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    DashboardComponent,
    BookinglistComponent,
    BookingformComponent,
    FeedbackformComponent,
    MessagesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    router,
    NgReduxModule,
    // StoreModule,
    AngularFireModule.initializeApp(config, firebaseAuthConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule
  ],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy},UserService, AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
