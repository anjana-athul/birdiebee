import { RouterModule, Routes} from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { AngularFireModule, AuthProviders, AuthMethods } from '@angular/fire/firebase-node';
import {AuthGuard} from './components/Services/authGuard'

import {LoginComponent} from './components/login/login.component';
import {SignupComponent} from './components/signup/signup.component';
import {BookingformComponent} from './components/bookingform/bookingform.component';
import {BookinglistComponent} from './components/bookinglist/bookinglist.component';
import {FeedbackformComponent} from './components/feedbackform/feedbackform.component';
import {MessagesComponent} from './components/messages/messages.component';


export const routes: Routes = [
 { path: '' , redirectTo: 'login' , pathMatch: 'full' },
 { path: 'login' , component: LoginComponent },
 { path: 'signup' , component: SignupComponent },
 { path: 'bookingform' , component: BookingformComponent,
canActivate:[AuthGuard] },
 { path: 'bookinglist' , component: BookinglistComponent,
canActivate:[AuthGuard] },
 { path: 'feedback' , component: FeedbackformComponent,
canActivate:[AuthGuard] },
 { path: 'messages' , component: MessagesComponent,
canActivate:[AuthGuard] },
];

 export const router: ModuleWithProviders = RouterModule.forRoot(routes)
 